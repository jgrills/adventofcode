#! /bin/bash

time ./exe
